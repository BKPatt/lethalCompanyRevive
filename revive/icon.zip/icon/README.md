# Revive
***ALL CLIENTS NEED THIS MOD INSTALLED*** 

This adds the ability to revive a player for a configurable amount of credits.

## V 1.0.0
### **[ New ]**

- Type 'revive' to pull up the revive UI
- Price is either flat (configurable), based on quota/{num_players}, or exponential

## Credit
- "Borrowed" code
    - malco (https://github.com/Malcolm-Q/LC-LateGameUpgrades)
    - winstxnhdw (https://github.com/winstxnhdw/lc-hax)