# Revive
***INSTALL THE DEPENDENCIES***  
***ALL CLIENTS NEED THIS MOD INSTALLED*** 
***THIS HAS NOT BEEN TESTED IN MULTIPLAYER AND IS VERY EARLY DEVELOPMENT. USE WITH DISCRETION***

This adds the ability to revive a player for 100 credits.

## V 0.0.1
### **[ New ]**

- Type 'revive [player_name]' to revive a dead player for 100 credits

### **[ Upcoming ]**

- List dead players
- Only revive players brought back to the ship


## Credit
- "Borrowed" code
    - malco (https://github.com/Malcolm-Q/LC-LateGameUpgrades)
    - winstxnhdw (https://github.com/winstxnhdw/lc-hax)