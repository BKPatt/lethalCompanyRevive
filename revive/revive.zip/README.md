# Revive
***ALL CLIENTS NEED THIS MOD INSTALLED*** 

This adds the ability to revive a player for 100 credits.

## V 1.0.0
### **[ New ]**

- Type 'revive [player_name]' to revive a dead player for 100 credits

### **[ Upcoming ]**

- List dead players
- Add variable pricing depending on Quota or average scrap per day (unsure)
- Add the ability to edit revive cost in the config file

## Credit
- "Borrowed" code
    - malco (https://github.com/Malcolm-Q/LC-LateGameUpgrades)
    - winstxnhdw (https://github.com/winstxnhdw/lc-hax)